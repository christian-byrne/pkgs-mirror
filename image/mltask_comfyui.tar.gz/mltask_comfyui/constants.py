import os

MLTASK_COMFYUI_API_URL = "https://comfy.api.mltask.com/v1"
SOCIAL_MAN_KEYS_FILE = os.path.dirname(os.path.realpath(__file__)) + "/socialman.json"
