## 2.0.0

* Added Stack version of the Randomize LoRAs node;
* Added Trigger words fields for the Randomize LoRAs nodes;
* Fixed Randomize LoRAs outputing duplicated LoRAs if the user selected the same LoRA multiple times;
* Added Random Text from Multiline node;
* Added Text Multiline With Variables node;

## 1.0.0

* Initial launch
* Added Randomize LoRAs node 