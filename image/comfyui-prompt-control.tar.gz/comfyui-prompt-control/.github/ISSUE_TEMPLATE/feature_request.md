---
name: Feature request
about: Suggest an idea for this project
title: "[FR]"
labels: ''
assignees: ''

---

**Describe what's missing**
Write a description of what you would like to see implemented.

**Additional context**
Add any other context or screenshots about the feature request here.
