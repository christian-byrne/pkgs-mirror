# DeepSeek
Unofficial implementation of DeepSeek for ComfyUI

# How to use
- apply api key in ：https://platform.deepseek.com/
- add api key in config.json
- use `DeepSeek Chat` node in comfyUI

# example
see workflow folder