# ComfyUI_SUNoise
Scaled Uniform Noise for Ancestral & Stochastic samplers and Noisy latent image
