long_side = 1024
seed = 0

screentone_scale = 0.8
color_scale = 0.25

# Call remotely
# Address_SDWUI_Base = F"http://10.32.134.199:8888/sdapi/v1"
# Call locally
# Address_SDWUI_Base = F"http://localhost:8888/sdapi/v1"
#Address_SDWUI_Base = F"http://127.0.0.1:8888/sdapi/v1"
#Address_SDWUI_Base = F"http://127.0.0.1:7860/sdapi/v1"
Address_SDWUI_Base = F"http://127.0.0.1:7860/sdapi/v1"
#Address_SDWUI_Base=F"http://y.miaomiao.li:6179/sdapi/v1"

Address_SDWUI_TextToImage = F"{Address_SDWUI_Base}/txt2img"
Address_SDWUI_Option = F"{Address_SDWUI_Base}/options"

File_Workplace = F"workspace/"
File_Output = F"Output/"

# Image_Name = F"__hakurei_reimu_touhou_drawn_by_ini_inunabe00__f36320cd7eef630772572a8fc987f330"
Image_Name = F"Image-Sketch-Input-1"

Img_JPG = F".jpg"
Img_PNG = F".png"

Cluster_Number = 15
