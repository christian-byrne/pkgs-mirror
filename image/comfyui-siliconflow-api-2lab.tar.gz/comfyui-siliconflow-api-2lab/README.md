# Silicon Flow
Unofficial implementation of siliconflow API for ComfyUI (https://siliconflow.cn/)

# How to use
- apply api key in ：https://cloud.siliconflow.cn/
- add api key in config.json

# example
see workflow folder