# Examples

## Cyber Dolphin

![cyberdolphin_example.png](cyberdolphin_example.png)

---

Get image prompt from OpenAI or a compatible API. By default `gpt-3.5-turbo` is used.

![img.png](img.png)

---

Compare the results of DALL·E and local SD models to see which one is better at generating images from text.


![img_1.png](img_1.png)
---
