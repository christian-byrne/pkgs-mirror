export const EXTENSION_KEY = "default_values_extension";
export const TARGETED_WIDGET_TYPES = [
  "customtext",
  "text",
  "number",
  "combo",
  "slider",
  "toggle",
];
export const MOD_KEYS = ["Control", "Meta", "Alt", "Shift", "Tab"];
