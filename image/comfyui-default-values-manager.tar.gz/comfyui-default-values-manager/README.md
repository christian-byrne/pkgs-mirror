
> #### Adds a row to the settings page:

![alt text](docs/pictures/settings-location.png)



> #### Clicking the `Edit Custom Defaults` button brings up this screen:



![alt text](docs/pictures/settings-dialog.png)

The custom defaults will only be applied when adding a node manually. It won't alter nodes loaded from workflows/refreshes or nodes that are copy and pasted.