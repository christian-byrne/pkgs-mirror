from .pipeline import StreamDiffusion
