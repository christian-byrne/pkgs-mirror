# comfyui-llm-assistant

## Installation

1. use `ComfyUI-Manager` or put this code into `custom_nodes`
2. `pip install -r requirements.txt`
3. add `config.yaml`. config your api key and other info.

