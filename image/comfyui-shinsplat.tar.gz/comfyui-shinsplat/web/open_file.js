

import { app } from "../../scripts/app.js";
import { api } from "../../scripts/api.js";
import { ComfyWidgets } from "../../scripts/widgets.js";

app.registerExtension({
	name: "shinsplat.opentextfile",
	async beforeRegisterNodeDef(nodeType, nodeData, app) {
		// do some stuff here
		}
	}
});
