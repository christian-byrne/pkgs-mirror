## TW-CUI-Util
This repository contains multiple 'utility' nodes for various ease-of-use improvements and combining a number of nodes necessary for a workflow into less.

---

Please refer to the [**wiki**](https://github.com/TW-CUI/TW-CUI-Util/wiki) for this project for details on what is included in this repository, usage information, 
contributor lists, etc.

---

This repository, unless otherwise specified, is licensed under GPL-3.0.
