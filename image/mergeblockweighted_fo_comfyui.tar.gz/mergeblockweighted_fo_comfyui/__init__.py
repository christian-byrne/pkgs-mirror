import custom_nodes.MergeBlockWeighted_fo_ComfyUI.script.MergeBlockWeightedNodes as MBWNodes

NODE_CLASS_MAPPINGS = {
    "MergeBlockWeighted":MBWNodes.MergeBlockWeighted
    }
