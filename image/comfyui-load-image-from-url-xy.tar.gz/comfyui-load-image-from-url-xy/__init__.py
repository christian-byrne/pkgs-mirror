from .nodes.load_image_url_node import LoadImageByUrlOrPathXY


NODE_CLASS_MAPPINGS = {
    "LoadImageFromUrlOrPathXY": LoadImageByUrlOrPathXY,
}

