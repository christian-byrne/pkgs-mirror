from .nodes import *

NODE_CLASS_MAPPINGS = {
    "Uncond Zero":uncondZeroNode,
}
