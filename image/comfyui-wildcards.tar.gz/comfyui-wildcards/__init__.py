from custom_nodes.comfyui_wildcards import wildcards
NODE_CLASS_MAPPINGS = {
    **wildcards.NODE_CLASS_MAPPINGS
}