# ComfyUI-Image-Matting


## Nodes

### Apply Matting

![image matting](https://github.com/hackkhai/ComfyUI-Image-Matting/blob/master/image_matting_workflow_example.png)

## workflow
[download sample workflow](https://github.com/hackkhai/ComfyUI-Image-Matting/blob/master/image_matting.json)
