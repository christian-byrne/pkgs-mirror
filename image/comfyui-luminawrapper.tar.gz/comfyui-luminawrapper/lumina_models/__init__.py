from .nextdit import NextDiT_2B_GQA_patch2, NextDiT_2B_patch2
