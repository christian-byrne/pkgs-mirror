# Testing

Any image in this folder should have it's workflow saved with it, and that workflow should generate the same image.