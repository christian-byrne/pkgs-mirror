# ComfyUI-HyperSDXL1StepUnetScheduler
ComfyUI sampler for HyperSDXL UNet

Ported from:
https://huggingface.co/ByteDance/Hyper-SD/blob/main/comfyui/ComfyUI-HyperSDXL1StepUnetScheduler/node.py
