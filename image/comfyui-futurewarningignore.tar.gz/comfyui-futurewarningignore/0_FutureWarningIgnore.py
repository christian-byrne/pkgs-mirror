import warnings
warnings.simplefilter(action='ignore', category=FutureWarning)

NODE_CLASS_MAPPINGS = {}
