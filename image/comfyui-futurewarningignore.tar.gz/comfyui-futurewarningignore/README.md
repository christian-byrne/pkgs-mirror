# ComfyUI-FutureWarningIgnore

Just put `0_FutureWarningIgnore.py` into `ComfyUI\custom_nodes` if you are fed up with FutureWarning messages in your Console
