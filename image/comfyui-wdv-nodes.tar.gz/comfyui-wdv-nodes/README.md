Sticking a .py directly into my custom_nodes folder doesn't fit my aesthetic. 

100% of code taken from https://gist.github.com/neggles/ecb6327251a9e274428d07636c727eb9. 

It's an interesting model check it out:
https://huggingface.co/waifu-diffusion/wdv-tests
![preview](https://github.com/BetaDoggo/ComfyUI-WDV-Nodes/blob/main/workflow-preview.png)
