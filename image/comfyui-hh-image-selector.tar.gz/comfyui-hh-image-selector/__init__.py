from .nodes.nodes import *

NODE_CLASS_MAPPINGS = {
    "Image Selector" : ImageSelector,
}

WEB_DIRECTORY = "./js"
__all__ = ['NODE_CLASS_MAPPINGS', 'WEB_DIRECTORY']