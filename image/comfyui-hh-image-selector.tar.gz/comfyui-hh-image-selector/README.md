# ComfyUI-HH-Image-Selector
comfuio custom node that returns an image from a batch based on selected criteria such as RGB value, brightness, etc (credits to chris goringe's custom nodes tutorial )
