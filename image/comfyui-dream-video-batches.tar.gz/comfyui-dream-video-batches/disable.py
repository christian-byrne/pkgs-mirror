# -*- coding: utf-8 -*-
def run_disable():
    pass


if __name__ == "__main__":
    run_disable()
