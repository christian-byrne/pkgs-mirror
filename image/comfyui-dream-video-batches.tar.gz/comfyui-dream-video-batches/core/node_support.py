# -*- coding: utf-8 -*-

ALWAYS_CHANGED_FLAG = float("NaN")