# comfyui_dagthomas

Custom nodes for ComfyUI

#### SDXL Auto Prompter

"subject" input field can be changed to support your style or lora, just add your subject and it will overwrite "man, woman ..." etc.

![image](https://github.com/dagthomas/comfyui_dagthomas/assets/4311672/bbe46597-1dbf-4f85-adbb-5a7f7bf95f77)

![Ref-FF_0067](https://github.com/dagthomas/comfyui_dagthomas/assets/4311672/e21a3b64-0a0e-4974-b16b-b09b0a470479)
![Ref-FF_0064](https://github.com/dagthomas/comfyui_dagthomas/assets/4311672/2632524d-d390-4c20-9630-f66f641204a1)
![Ref-FF_0066](https://github.com/dagthomas/comfyui_dagthomas/assets/4311672/f8b71c87-1167-4bc1-b78d-35955a725662)

> Easy prompting for generation of endless random art pieces and photographs!
