class BaseNode:
    CATEGORY = "PromptUtilities"