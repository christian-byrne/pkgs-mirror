# ComfyUI-Embeddings-Tools

## **Examples:**  
Node for append "embedding:" to the embedding name if such embedding is in the folder "ComfyUI\models\embeddings", and node to get a list of all embeddings
<img src="https://github.com/ZeDarkAdam/ComfyUI-Embeddings-Tools/blob/main/examples/EmbeddingsNameLoader%2C%20EmbendingList%20example.png" width="720">

## **Install:**
To install, drop the "_**ComfyUI-Embeddings-Tools**_" folder into the "_**...\ComfyUI\ComfyUI\custom_nodes**_" directory and restart UI.
