# ComfyUI Checkpoint Automatic Config

This node was designed to help with checkpoint configuration.
