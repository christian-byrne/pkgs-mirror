# comfyui-marnodes
my simple little random nodes for ComfyUI

Mostly a placeholder with some basic custom qol stuff.

Workflow Settings:
![image](https://github.com/marduk191/comfyui-marnodes/assets/1769686/a9bb6359-0b60-4eac-a144-07f4666e16a8)

String nodes:
![image](https://github.com/marduk191/comfyui-marnodes/assets/1769686/a4a5895a-7251-404e-99ca-96e13a0a4367)

Material Node Colors:
![image](https://github.com/user-attachments/assets/36151ec1-9889-4249-8900-e125bec5574c)


Worflow:
![marduk191-beginner_flow_v1](https://github.com/marduk191/comfyui-marnodes/assets/1769686/1ca8faa9-c223-4180-b279-55f773da9938)
