from . import prediction_boost

NODE_CLASS_MAPPINGS = {
    "PredictionBoost": prediction_boost.PredictionBoost,
}

NODE_DISPLAY_NAME_MAPPINGS = {
    "PredictionBoost": "Prediction Boost"
}
