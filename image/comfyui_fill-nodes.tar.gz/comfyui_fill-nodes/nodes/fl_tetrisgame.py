class FL_TetrisGame:
    @classmethod
    def INPUT_TYPES(s):
        return {"required": {}}

    RETURN_TYPES = ()
    FUNCTION = "execute"
    CATEGORY = "🏵️Fill Nodes/games"

    def execute(self):
        return ()