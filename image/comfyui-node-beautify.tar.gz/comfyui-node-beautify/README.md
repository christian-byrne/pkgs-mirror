﻿# ComfyUI Node Beautify
This is an Extension for [ComfyUI](https://github.com/comfyanonymous/ComfyUI), which helps formatting the workflow.

## Feature
This will add a button, **Beautify**, to the menu that rounds the **size** and **position** of each **node** and **group** in a workflow using a specified value

## Config
You can click the cog icon to open the settings, and edit the **Beautify Grid Size** field to change the value used for rounding
