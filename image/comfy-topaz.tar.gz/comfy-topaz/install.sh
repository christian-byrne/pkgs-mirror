#!/bin/sh
# copy js to extensions directory (useful for development)
mkdir -p ../../web/extensions/topaz
cp -r ./web/js/* ../../web/extensions/topaz/ 