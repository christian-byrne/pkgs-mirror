# -*- coding: utf-8 -*-
def run_uninstall():
    pass


if __name__ == "__main__":
    run_uninstall()
