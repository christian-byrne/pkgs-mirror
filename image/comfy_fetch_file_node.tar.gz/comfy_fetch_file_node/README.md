Creates a fetch file node in comfy:

## Installation:
- open comfy-ui manager
- install from github: https://github.com/ultrafro/comfy_fetch_file_node

## Usage:
- you put in a url to download from (e.g. Google cloud storage)
- you put in the output file's name

![image](https://github.com/user-attachments/assets/c989cb5e-9416-40a4-91ab-79c97fbac6a2)


This was made to make runpod setup easier. The goal is to have everything happen in the workflow
