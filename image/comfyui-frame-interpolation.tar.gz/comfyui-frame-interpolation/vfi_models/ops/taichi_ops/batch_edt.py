def batch_edt(img, block=1024):
    raise NotImplementedError()