## ComfyUI Substring

Just a simple substring node that takes *text* and *length* as input, and outputs the first *length* characters.

To install, just git clone this repo in \ComfyUI\custom_nodes\