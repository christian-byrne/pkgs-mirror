# @article{suvorov2021resolution,
#   title={Resolution-robust Large Mask Inpainting with Fourier Convolutions},
#   author={Suvorov, Roman and Logacheva, Elizaveta and Mashikhin, Anton and Remizova, Anastasia and Ashukha, Arsenii and Silvestrov, Aleksei and Kong, Naejin and Goka, Harshith and Park, Kiwoong and Lempitsky, Victor},
#   journal={arXiv preprint arXiv:2109.07161},
#   year={2021}
# }
