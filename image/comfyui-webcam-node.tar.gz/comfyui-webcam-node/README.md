Example workflow

![](workflow-example.png)

Need to run at localhost/https for webcam to work

## How to Use

* Install the custom node by placing the repo inside custom_nodes. No extra requirements are needed to use it. 
* You can find the node under Webcam/Webcam Capture.
* Press start capture to start using the camera.
* If you enable auto queue, you can keep creating images from the webcam input thanks to the seed trick.
