# comfyui-imagesubfolders
Clone of the comfyui image loader node with subfolder support.

This is a line for line copy of the official comfyui image loader except it supports checking subfolders under the input folder.  This allows you to organise poses, etc into folders within the input directory.  It excludes the clipspace folder inside the input folder.

![image](https://github.com/catscandrive/comfyui-imagesubfolders/assets/10904002/de702562-7bda-4af5-b05d-49ec46fc5719)

