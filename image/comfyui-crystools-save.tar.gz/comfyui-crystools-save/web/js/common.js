export const commonPrefix = '🪛';
