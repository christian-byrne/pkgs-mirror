"""
@author: Crystian
@title: Crystools-save
@nickname: Crystools-save
@version: 1.2.4
@project: "https://github.com/crystian/ComfyUI-Crystools-save",
@description: With this quality of life extension, you can save your workflow with a specific name and include additional details such as the author, a description, and the version (in metadata/json) IG: https://www.instagram.com/crystian.ia
"""

WEB_DIRECTORY = "web"
NODE_CLASS_MAPPINGS = {}
NODE_DISPLAY_NAME_MAPPINGS = {}
