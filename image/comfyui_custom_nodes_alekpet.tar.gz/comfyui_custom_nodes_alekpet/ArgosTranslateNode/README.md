# Argos Translate **offline** translation nodes for ComfyUI,translate promt from other languages into english.

### Note: Offline translate after load language package

**Supported languages:**
Arabic, Azerbaijani, Catalan, Chinese, Czech, Danish, Dutch, English, Esperanto, Finnish, French, German, Greek, Hebrew, Hindi, Hungarian, Indonesian, Irish, Italian, Japanese, Korean, Persian, Polish, Portuguese, Russian, Slovak, Spanish, Swedish, Turkish, Ukrainian

> Includes:
> **ArgosTranslateCLIPTextEncodeNode** - translate text, and return CONDITIONING
>
> **ArgosTranslateTextNode** - translate text and return text (STRING)

__Used module__ **Argos Translate**: https://github.com/argosopentech/argos-translate

## Image:

![Argos Translate Nodes](https://github.com/AlekPet/ComfyUI_Custom_Nodes_AlekPet/raw/master/ArgosTranslateNode/image_argos_translate_nodes.jpg)

> Installation:

1. Go to where install ComfyUI
2. Find folder custom_nodes
3. Open your shell
4. Git clone
5. Run ComfyUI
6. Wait first run, not speed, if error, after installing, restart ComfyUI.
