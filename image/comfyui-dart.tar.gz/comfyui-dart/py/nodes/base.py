class BaseNode:
    CATEGORY = "Dart"
