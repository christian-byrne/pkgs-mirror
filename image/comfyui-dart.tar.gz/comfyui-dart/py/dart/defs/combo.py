RATINGS = {
    "rating:general": "rating:sfw, rating:general",
    "rating:sensitive": "rating:sfw, rating:sensitive",
    "rating:questionable": "rating:nsfw, rating:questionable",
    "rating:explicit": "rating:nsfw, rating:explicit",
}

LENGTHS = {
    "very_short": "<|very_short|>",
    "short": "<|short|>",
    "long": "<|long|>",
    "very_long": "<|very_long|>",
}
