RATINGS = ["sfw", "general", "sensitive", "nsfw", "questionable", "explicit"]

ASPECT_RATIOS = ["ultra_wide", "wide", "square", "tall", "ultra_tall"]

LENGTHS = ["very_short", "short", "medium", "long", "very_long"]

IDENTITIES = ["none", "lax", "strict"]
