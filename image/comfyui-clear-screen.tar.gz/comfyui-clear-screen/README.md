﻿# ComfyUI Clear Screen
This is an Extension for [ComfyUI](https://github.com/comfyanonymous/ComfyUI), which adds a **CLS** button that clears the console window.

### But Why ?
Useful for benchmarking, extension developing, or when you just want to clear the console ~~after it craps out tons of errors~~.
