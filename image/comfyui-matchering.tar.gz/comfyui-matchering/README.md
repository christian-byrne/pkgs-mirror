# ComfyUI-Matchering
A [Matchering](https://github.com/sergree/matchering)-node for ComfyUI

![Matchering node](https://github.com/user-attachments/assets/21be8301-16c6-4f9c-b57b-c34fa7799c7e)
*Basic Matchering node*


![Matchering (Advanced)](https://github.com/user-attachments/assets/52260bf8-9965-4bbb-a475-0e3bae418d59)
*Advanced Matchering node*
