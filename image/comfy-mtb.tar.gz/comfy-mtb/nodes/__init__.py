"""MTB Nodes module."""
