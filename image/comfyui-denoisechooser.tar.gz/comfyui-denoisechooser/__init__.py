from .node import DenoiseChooser

NODE_CLASS_MAPPINGS = {
   "DenoiseChooser|Koushakur": DenoiseChooser
}

NODE_DISPLAY_NAME_MAPPINGS = {
   "DenoiseChooser|Koushakur": "Denoise Chooser"
}
