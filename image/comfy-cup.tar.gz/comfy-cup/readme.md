# ComfyUI-BlenderAI-node Bridge
## Features
1. ComfyUI-BlenderAI-node thumbnail service(depends on ComfyUI-Studio)
2. ComfyUI-BlenderAI-node specify InputImage/SaveImage Nodes etc.
3. ComfyUI-BlenderAI-node node-diff/queue service.
## Installation
```
cd ComfyUI/custom_nodes
git clone https://github.com/AIGODLIKE/ComfyUI-CUP.git
```
## Note
1. This repo only used for [ComfyUI-BlenderAI-node](https://github.com/AIGODLIKE/ComfyUI-BlenderAI-node) !
2. This repo do not provide any nodes for web-end.