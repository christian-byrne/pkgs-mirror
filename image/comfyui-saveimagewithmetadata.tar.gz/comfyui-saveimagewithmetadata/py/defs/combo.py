SAMPLER_SELECTION_METHOD = ["Farthest", "Nearest", "By node ID"]
