SAMPLERS = {
    "KSampler": {
        "positive": "positive",
        "negative": "negative",
    },
    "KSamplerAdvanced": {
        "positive": "positive",
        "negative": "negative",
    },
}
