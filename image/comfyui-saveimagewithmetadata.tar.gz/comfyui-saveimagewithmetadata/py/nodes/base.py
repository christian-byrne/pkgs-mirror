class BaseNode:
    CATEGORY = "SaveImage"
