from .nodes import *

NODE_CLASS_MAPPINGS = {
    "Unet Temperature":UnetTemperaturePatch,
    "CLIP Temperature":CLIPTemperaturePatch,
}
