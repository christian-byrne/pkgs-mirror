# For learning purpose

# ComfyUI Preview Magnifier (Single Image, Comparer, XY-Plot)
Custom node that preview image with a magnifier.

![Magnifier Example](example_preview.png)

Custom node that compare two images with a magnifier.

![Magnifier Comparer Example](example_comparer.png)

Custom node that support xy plot with a magnifier.

![Magnifier XY](example_xy.png)
