# All-IN-ONE-style
all styles for comfyui
