# comfyui-text-with-comments
multiline text node that strips comments before passing output down stream
