export const nodeConfig = {
    nodeTitle: "Google Image Search",
    projectDirName: "comfy-tiktok",
    nodeBackendName: "Google Image Search",
    graphName: "Google Image Search",
    mainContainerId: "google-search-node-main-container",
    getResponseId: "google-search-node-get-response",
    getContainerId: "google-search-node-get-container",
};
