from .node import ImageSearchNode

NODE_CLASS_MAPPINGS = {"Google Image Search": ImageSearchNode}
WEB_DIRECTORY = "./web"
