## Works with any Depth Map and visualizes the applied version of it inside ComfyUI
![image](https://github.com/gokayfem/ComfyUI-Depth-Visualization/assets/88277926/0b63c2ed-60d4-44a6-9d44-b3548ec58d48)

## Acknowledgements
[flowtyone](https://github.com/flowtyone/ComfyUI-Flowty-TripoSR)
