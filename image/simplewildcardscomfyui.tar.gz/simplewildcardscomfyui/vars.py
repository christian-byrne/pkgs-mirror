from pathlib import Path

root_directory = Path(__file__).parent
module_js_directory = root_directory / "js"
application_root_directory = Path(__file__).parent.parent.parent
