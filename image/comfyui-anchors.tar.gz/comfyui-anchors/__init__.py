ANCHOR_VERSION = "0.1.0"

print(f"### Loading: ComfyUI-Anchors (V{ANCHOR_VERSION})")

NODE_CLASS_MAPPINGS = {}
WEB_DIRECTORY = "./dist"

__all__ = ["NODE_CLASS_MAPPINGS", "WEB_DIRECTORY"]
