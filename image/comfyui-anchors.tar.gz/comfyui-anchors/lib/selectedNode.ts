import { AnchorNode } from './AnchorNode';

export const selectedNode: { node: AnchorNode | null } = { node: null };
