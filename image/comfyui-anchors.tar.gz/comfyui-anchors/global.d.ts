export {}; // Load-bearing Export

// TODO: Oh god... What have I gotten myself into...?
// Nah, this'll be fun.
declare global {
  const LiteGraph: any;
  const LGraphCanvas: any;
}
