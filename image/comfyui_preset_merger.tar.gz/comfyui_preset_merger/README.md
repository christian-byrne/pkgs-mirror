# ComfyUI_Preset_Merger
Merge checkpoint models by preset

This contains one node that will be available in `advanced/model_merging` called `ModelMergeByPreset`

# Sine examples
**Note**: *Missing sawtooth examples.* 
![preset_grids](https://github.com/WASasquatch/ComfyUI_Preset_Merger/assets/1151589/1772e446-9534-464d-84fb-b00a46409423)
