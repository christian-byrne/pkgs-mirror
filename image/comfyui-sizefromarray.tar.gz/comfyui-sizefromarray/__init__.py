from .nodes.random import *

NODE_CLASS_MAPPINGS = {
    "SizeFromArray": SizeFromArray,
}

NODE_DISPLAY_NAME_MAPPINGS = {
    "SizeFromArray": "Retrieve random pair of size from array",
}
