from custom_nodes.comfyui_save_image_with_options import saveImage
NODE_CLASS_MAPPINGS = {
    **saveImage.NODE_CLASS_MAPPINGS
}