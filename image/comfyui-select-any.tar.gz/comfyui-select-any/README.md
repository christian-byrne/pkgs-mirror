# ComfyUI-Select-Any
a comfyui custom node, which can select value from inputs

## Nodes

### SelectAnyValues

can choose one active value from inputs by your inputs
![desc](./doc/SelectAnyValues.png)



![images](./doc/SelectAnyValues-2.png)
