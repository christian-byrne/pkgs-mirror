
# need refactor
sd_document_data = dict()
def set_sd_document_data(data):
    global sd_document_data
    sd_document_data = data
def get_sd_document_data():
    return sd_document_data

sd_special_get_layer_options = []
def set_sd_special_get_layer_options(data):
    global sd_special_get_layer_options
    sd_special_get_layer_options = data
def get_sd_special_get_layer_options():
    return sd_special_get_layer_options

sd_special_get_bound_layer_options = []
def set_sd_special_get_bound_layer_options(data):
    global sd_special_get_bound_layer_options
    sd_special_get_bound_layer_options = data
def get_sd_special_get_bound_layer_options():
    return sd_special_get_bound_layer_options

sd_special_send_layer_options = []
def set_sd_special_send_layer_options(data):
    global sd_special_send_layer_options
    sd_special_send_layer_options = data
def get_sd_special_send_layer_options():
    return sd_special_send_layer_options
