

from .sbs import SideBySide

NODE_CLASS_MAPPINGS = {
    "SBS_by_SamSeen": SideBySide
}

NODE_DISPLAY_NAME_MAPPINGS = {
    "SBS_by_SamSeen": "👀 Side By Side"
}
 