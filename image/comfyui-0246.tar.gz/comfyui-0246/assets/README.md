Random assets for the README
