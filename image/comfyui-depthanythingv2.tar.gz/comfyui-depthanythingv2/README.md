# ComfyUI nodes to use DepthAnythingV2
https://depth-anything-v2.github.io

Models autodownload to `ComfyUI\models\depthanything` from https://huggingface.co/Kijai/DepthAnythingV2-safetensors/tree/main

![image](https://github.com/kijai/ComfyUI-DepthAnythingV2/assets/40791699/6e9f190a-02da-4176-9cca-6e4e4b0ad35d)
