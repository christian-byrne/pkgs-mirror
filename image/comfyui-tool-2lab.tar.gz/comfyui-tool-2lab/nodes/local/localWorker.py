
from ..constants import get_project_category

NODE_CATEGORY = get_project_category("local")