class AnyType(str):
    def __ne__(self, __value: object) -> bool:
        return False

any = AnyType("*")