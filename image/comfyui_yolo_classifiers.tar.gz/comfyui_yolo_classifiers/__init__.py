from .classifiers import *

NODE_CLASS_MAPPINGS = {
    'YOLO Classifier Model Loader': YOLOClassifierModelLoader,
    'YOLO Classify': YOLOClassify
}
