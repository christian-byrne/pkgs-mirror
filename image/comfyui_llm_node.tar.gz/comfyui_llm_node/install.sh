#!/bin/sh

pip install -r requirements.txt
pip install -i https://pypi.org/simple/ bitsandbytes