from .image_captioner import ImageCaptioner

NODE_CLASS_MAPPINGS = {
    "ImageCaptioner": ImageCaptioner
}

NODE_DISPLAY_NAME_MAPPINGS = {
    "ImageCaptioner": "Image Captioner"
}
