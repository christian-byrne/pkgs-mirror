# WTF? - a debug node for ComfyUI

This node provides a simple way to view the output of many nodes, without leaving ComfyUI.

### Simple string
![image](https://github.com/user-attachments/assets/f3b2f797-77f2-4fb5-b3f0-8b768b386448)

### Tensor
![image](https://github.com/user-attachments/assets/79f17776-0bcf-4066-9f8a-33ec16a19d6d)

### An OUTPUT_IS_LIST node (Rebatched images)
![image](https://github.com/user-attachments/assets/edf500ac-edce-4b58-8d2a-074bf1b8c4cc)

### A list node without OUTPUT_IS_LIST
![image](https://github.com/user-attachments/assets/d065ca60-189b-4b0b-826e-248da1a73a2e)

_"What's that field?"_
