from .openpose_keypoint_extractor import NODE_CLASS_MAPPINGS
__all__ = ["NODE_CLASS_MAPPINGS"]
