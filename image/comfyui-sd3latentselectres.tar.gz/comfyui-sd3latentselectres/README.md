`cd custom_nodes`

`git clone https://github.com/GavChap/ComfyUI-SD3LatentSelectRes .`

You'll get a new node called SD3 Latent Select Resolution, you can pick the x and y sizes from a list.

![image](https://github.com/GavChap/ComfyUI-SD3LatentSelectRes/assets/1280021/88008968-b1c2-4752-9a16-019dcd2aee3d)

Sizes cunningly borrowed from humblemikey
