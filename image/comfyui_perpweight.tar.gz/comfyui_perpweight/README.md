# ComfyUI_PerpWeight

A novel weighting scheme for token vectors from CLIP. Allows a wider range of values for the weight.


Inspired by Perp-Neg.
