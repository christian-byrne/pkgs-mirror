# Code of Conduct

We’re here to share and improve code together. Here are a few simple guidelines:

1. **Be respectful** and considerate in your communication.
2. **Focus on the code** and technical discussions.
3. **Collaborate openly** and help others if you can.

Let’s build something great together!
