class BaseNode:
    CATEGORY = "MaskText"
