#credit to city96 for this module
#from https://github.com/city96/ComfyUI_ExtraModels/