# ComfyUI_LibreTranslate
Use LibreTranslation in ComfyUI
https://github.com/LibreTranslate/LibreTranslate

1- Copy the node to ``ComfyUI\custom_nodes``

2- Install LibreTranslate
``pip install libretranslate``

Before using the node, run ``libretranslate`` from the command line.
You don't need to open the link: http://localhost:5000

![1717782256961](https://github.com/seghier/ComfyUI_LibreTranslate/assets/6026588/340cac53-fb64-4d63-999b-32039526cade)
