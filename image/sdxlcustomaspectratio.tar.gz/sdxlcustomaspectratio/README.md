# SDXLCustomAspectRatio
A quick and easy ComfyUI custom node for setting SDXL-friendly aspect ratios

git clone or download this python file directly to comfyui/custom_nodes/
