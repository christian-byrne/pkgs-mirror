# EmbeddingsCurveEditor_ComfyUI
Edit embeddings  with a curve. Actually should work on any  1D input tensor. Tested with [IPAdapter-Plus](https://github.com/cubiq/ComfyUI_IPAdapter_plus/)

![example](https://github.com/chris-the-wiz/EmbeddingsCurveEditor_ComfyUI/blob/main/images/example.png?raw=true)
