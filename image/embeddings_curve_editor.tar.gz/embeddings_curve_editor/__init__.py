from .EmbeddingsCurveEditor import *

NODE_CLASS_MAPPINGS = {
    "Embeddings Curve Editor": EmbeddingsCurveEditor,
    }