from .SimpleCounter import NODE_CLASS_MAPPINGS
WEB_DIRECTORY = "./js"
__all__ = ['NODE_CLASS_MAPPINGS','WEB_DIRECTORY']
