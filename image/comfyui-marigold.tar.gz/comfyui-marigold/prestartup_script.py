import os
os.environ["OPENCV_IO_ENABLE_OPENEXR"] = "1"