修改的 fooocus 文件

vae_interpose.py
preprocessors.py
