# ComfyUI_BaiKong_Node

Get the colors palette from image